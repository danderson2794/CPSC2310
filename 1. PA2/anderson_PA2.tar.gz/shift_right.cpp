#include "header.h"

void shift_right(int *acc, int *mq, int *c)
{
    if (*acc % 2 == 1)
    {
        *acc /= 2;
        if (*c == 1)
        {
            *acc += 128;
            *c = 0;
        }
        *mq /=2;
        *mq += 128;
    }
    else if (*acc % 2 == 0)
    {
        *acc /= 2;
        if (*c == 1)
        {
            *acc += 128;
            *c = 0;
        }
        *mq /= 2;
    }
}