#include "header.h"
void check_product(int mdr, int mq, int size)
{
    cout << "check:" << setw(17) << " " << "binary   decimal" << endl;
    cout << setw(21) << " ";
    prt_bin(mdr, size);
    cout << setw(8) << " " << mdr << endl;
    cout << setw(12) << " " << "x" << setw(8) << " ";
    prt_bin(mq, size); 
    cout << " x" << setw(6) << " " << mq << endl;
    cout << setw(14) << " " << "---------------" << setw(5) << " " << "------"
         << endl;
    cout << setw(13) << " ";
    mdr *= mq;
    prt_bin(mdr, 16);
    cout << setw(6) << " " << mdr << endl;
}