#include "header.h"

/* 
    This function immulates the steps for 8-bit x 8-bit multiplication.
*/

void prt_steps(int c, int acc, int mdr, int mq, int size)
{
    for(int i = 0; i < size; i++)
    {
        cout << endl << "step " << i + 1 << ":   " << c << " ";
        prt_bin(acc, size);
        cout << " ";
        prt_bin(mq, size);
        cout << endl << "          " << "+ ";

        if (mq % 2 == 1)
        {
            prt_bin(mdr, size);
            cout << "        " << "^ add based on lsb=1" << endl;
            cout << "          ----------" << endl;
            acc += mdr;
            cout << "          " << c <<  " ";
            prt_bin(acc, size);
            cout << " ";
            prt_bin(mq, size);
            cout << endl << "       " << ">>" << "                     " <<           "shift right" << endl;

            shift_right(&acc, &mq, &c);
            cout << "          " << c << " ";
            prt_bin(acc, size);
            cout << " ";
            prt_bin(mq, size);
            cout << endl << "---------------------------------------------------" << endl;
        }

        else if (mq % 2 == 0)
        {
            prt_bin(0, size);
            cout << "        " << "^ no add based on lsb=0" << endl;
            cout << "          ----------" << endl;
            cout << "          " << c <<  " ";
            prt_bin(acc, size);
            cout << " ";
            prt_bin(mq, size);
            cout << endl << "       " << ">>" << "                     " <<           "shift right" << endl;
            shift_right(&acc, &mq, &c);
            cout << "          " << c << " ";
            prt_bin(acc, size);
            cout << " ";
            prt_bin(mq, size);
            cout << endl;
            cout << "---------------------------------------------------" << endl;

        }
    }
}