#include "header.h"

void prt_bin(int value, int length)
{
    int i;
    for( i=(length-1); i>=0; i--){
        if((value>>i)&1) 
            putchar('1'); 
        else 
            putchar('0');
    }
}