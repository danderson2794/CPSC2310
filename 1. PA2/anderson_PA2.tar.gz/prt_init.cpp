#include "header.h"

/*
    This function prints the first part of the multiplication process before step 1.
*/

void prt_init(int mdr, int mq,int size)
{
    cout << "\n\nc and acc set to 0" << endl << "mq set to multiplier    = " << mq        << " decimal and ";
    prt_bin(mq, size);
    cout << " binary." << endl;

    cout << "mdr set to multiplicand = " << mdr << " decimal and ";
    prt_bin(mdr, size);
    cout << " binary." << endl;
    cout << "-----------------------------------------------------------------";
    cout << endl;

}